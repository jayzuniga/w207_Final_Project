import requests, bs4, pandas as pd, numpy as np
import hashlib # use this to hash game key
import collections 

# Web scrapping 
# Try an example on MIT SIMULATOR, https://www.sportschatexperts.com/index/capperhistory/capper_id/68/
def get_html(url):
    html = requests.get(url)
    try:
        html.raise_for_status()
    except Exception as exc:
        print('There was a problem: %s' % exc)
    html = bs4.BeautifulSoup(html.text, "html5lib")
    return html

def get_next_url(html):
    # find the next button
    return html.find('a', string='Next')['href']

def merge_table(url, stop_page=-1, data=[]):
    cur_page = 0
    while True:
        cur_page += 1
        if (str(url)[-2:]=='00'):
            print("\tProcess %s ..." % url)
        html = get_html(url)
        table = html.find('section', class_='leaderboards diffpadding').div.table
        table_body = table.find('tbody')       
        rows = table_body.find_all('tr', class_='leaderboards_row2 fix-border-bottom ph-first-row')
        for row in rows:
            cols = row.find_all('td')
            # make sure the targeted row for extraction has 10 columns
            if len(cols) == 10:
                # only want to keep these columns
                keep_columns = [1, 2, 3, 4, 5, 6, 7, 8]
                cols = [ele.text.strip() for ele in [cols[i] for i in keep_columns]]
                data.append([ele for ele in cols if ele]) # Get rid of empty values
        url = get_next_url(html)
        if (url == '#') or cur_page >= stop_page:
            break
data=[]
merge_table('https://www.sportschatexperts.com/index/capperhistory/capper_id/68/', 2)

# Create a dataframe to hold historical bets for the handicapper 
# Add column headers

def crawl_history():
    names = [
    'Smart',
    'Bartley',
    'Aronson',
    'Burns',
    'Barone', # not in Ji's original list
    'Bitler',
    'Power',
    'Ross',
    'Diamond',
    'Trapp',
    'Sports',
    'Eddie',
    'Schule',
    'DAmico',
    'Duffy',
    'Thomas',
    'Hunter',
    'Compeau', # not in Ji's original list
    'Syndicate',
    'Lundin',
    'Simulator',
    'Wilson',
    'Monohan',
    'Vinceletti',
    'Rickenbach',
    'Higgs',
    'Nover',
    'Brown',
    'Karpinski',
    'Rogers'
    ]

    links = [
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/44/", 
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/33/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/50/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/67/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/69/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/65/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/62/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/66/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/36/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/29/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/45/", 
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/38/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/52/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/35/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/37/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/53/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/41/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/56/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/58/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/61/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/68/", 
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/30/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/43/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/46/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/57/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/40/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/51/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/42/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/60/",
    "https://www.sportschatexperts.com/index/capperhistory/capper_id/55/",
    ]
    
    handicappers_dict = collections.OrderedDict(zip(names, links))
    
    for k, v in handicappers_dict.items():
        data=[]
        merge_table(v, 9999, data)
        #print(data)
        df = pd.DataFrame(data, columns=['League', 'Game', 'Date', 'Play', 'Line Selected', 'Type', 'Score', 'Result'])
        filename = 'HC' + str(list(handicappers_dict.keys()).index(k)+1)
        
        # produce a hashed gamekey for the game
        df["GameKey"] = df[['League', 'Game', 'Date']].apply(lambda x: hashlib.md5(''.join(x).encode('utf-8')).hexdigest(), axis=1)

        # home team is always on the right?
        df["Home"] = df["Game"].apply(lambda x: x.split('vs.')[1].strip().upper())

        # away team is always on the left?
        df["Away"] = df["Game"].apply(lambda x: x.split('vs.')[0].strip().upper())

        # strip out type of bet
        df["Bet"] = df["Line Selected"].apply(lambda x: x.split(':')[0].strip().upper())

        # strip out which team the bet is on
        df["On"] = df["Play"].apply(lambda x: x.split('Play on ')[1].strip().upper())

        # convert game time to datetime format 
        df["GameTime"] = df["Date"].apply(lambda x: pd.to_datetime(x))

        # strip out juice
        df["Juice"] = df["Line Selected"].apply(lambda x: x.split(': ')[1].strip() if ("Money Line" in x) else (x.split(': ')[1].split('/')[0].strip() if ("Total" in x) else x.split(': ')[1].split('/')[1].strip()))

        # MLWinner: either home or away team for ML bets
        conditions = [
        (df['On'] == df['Home']) & (df['Bet'] == 'MONEY LINE') & (df['Result'] == 'Win'), 
        (df['On'] == df['Away']) & (df['Bet'] == 'MONEY LINE') & (df['Result'] == 'Win'), 
        (df['On'] == df['Home']) & (df['Bet'] == 'MONEY LINE') & (df['Result'] == 'Loss'), 
        (df['On'] == df['Away']) & (df['Bet'] == 'MONEY LINE') & (df['Result'] == 'Loss')
        ]
        choices = ['Home', 'Away', 'Away', 'Home']
        df['MLWinner'] = np.select(conditions, choices, default='')

        # MLBet: either home or away team for ML bets
        conditions = [
        (df['On'] == df['Home']) & (df['Bet'] == 'MONEY LINE'), 
        (df['On'] == df['Away']) & (df['Bet'] == 'MONEY LINE')
        ]
        choices = ['Home', 'Away']
        df['MLBet'] = np.select(conditions, choices, default='')
        
        columns_to_keep = ['League', 'GameKey', 'GameTime', 
                   'Home', 'Away',
                   'Bet', 'On',
                   'Juice', 'Type', 'Result',
                   'MLBet', 'MLWinner']
        #print(df[columns_to_keep].head())
        df[columns_to_keep].to_pickle(filename + '.gz', compression="gzip")       

crawl_history()